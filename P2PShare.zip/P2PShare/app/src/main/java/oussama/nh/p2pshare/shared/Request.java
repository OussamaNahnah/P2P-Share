package oussama.nh.p2pshare.shared;

import android.support.annotation.Nullable;

import java.io.Serializable;


public class Request implements Serializable {
    String pair_ip;
    String pair_name;
    String server_ip;
    String msg;
    int port;
    int password;
    public Request(String pair_ip,String pair_name,String server_ip,int port,int password,@Nullable String msg){
        this.pair_ip=pair_ip;
        this.pair_name=pair_name;
        this.server_ip=server_ip;
        this.port=port;
        this.password=password;
        this.msg=msg;

    }

    public int getPassword() {
        return password;
    }

    public String getPair_ip() {
        return pair_ip;
    }

    public String getPair_name() {
        return pair_name;
    }

    public String getServer_ip() {
        return server_ip;
    }

    public String getMsg() {
        return msg;
    }

    public int getPort() {
        return port;
    }

    public void setPair_ip(String pair_ip) {
        this.pair_ip = pair_ip;
    }

    public void setPair_name(String pair_name) {
        this.pair_name = pair_name;
    }

    public void setServer_ip(String server_ip) {
        this.server_ip = server_ip;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public void setPassword(int password) {
        this.password = password;
    }
}
