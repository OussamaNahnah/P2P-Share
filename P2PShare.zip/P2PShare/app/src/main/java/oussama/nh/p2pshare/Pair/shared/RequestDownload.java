package oussama.nh.p2pshare.Pair.shared;

import android.os.Environment;
import android.util.Log;
import android.view.View;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

import oussama.nh.p2pshare.Pair.Pair;
import oussama.nh.p2pshare.shared.File_;
import oussama.nh.p2pshare.shared.Utils;

public class RequestDownload implements Runnable{
    Pair pair;
    int port ;
File_ file_;




    public RequestDownload(Pair pair, int port, File_ file_) {
        this.pair = pair;
        this.port = port;
        this.file_ = file_;
    }

    @Override
    public void run() {
        file_.setRequster(Utils.getIPAddress(true));
        Log.i("ResqtDow","^:^");

        Log.i("ResqtDow","^:^^");
        DatagramSocket socket=null;
        try {
             socket = new DatagramSocket();
            ByteArrayOutputStream bStream = new ByteArrayOutputStream();
            ObjectOutput oo = new ObjectOutputStream(bStream);
            Log.i("ResqtDow","^:^^^");
            oo.writeObject(file_);
            oo.close();
            Log.i("ResqtDow","^:^^^^^^^");
            byte[] serializedMessage = bStream.toByteArray();
            DatagramPacket send_= new DatagramPacket(serializedMessage,
                    serializedMessage.length, InetAddress.getByName(file_.getOwner()), port);
            Log.i("ResqtDow","^:ù");
            socket.send(send_);
            socket.close();





        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (socket!=null)socket.close();
        }

        ServerSocket serverSocket =null;
        Socket clientSocket =null;
        //while (true){


            try {
                Log.i("ResqtDow","a");
                serverSocket = new ServerSocket(9183);
                Log.i("ResqtDow","b");
                clientSocket = serverSocket.accept();
                Log.i("ResqtDow","c");
                byte[] bytes = new byte[1024];
                InputStream is = clientSocket.getInputStream();
                Log.i("ResqtDow","c");

              /*  BufferedOutputStream bos = new BufferedOutputStream(
                        new FileOutputStream(Environment.getExternalStorageDirectory()+
                                File.separator+
                                "aaP2PShare"+
                                File.separator
                                +file_.getName()));*/
                BufferedOutputStream bos = new BufferedOutputStream(
                        new FileOutputStream(file_.getName()));
                /*BufferedOutputStream bos = new BufferedOutputStream(
                        new FileOutputStream(Environment.getExternalStorageDirectory()+ File.separator +"aaP2PShare"+ File.separator +file_.getName()));*/
                Log.i("ResqtDow","b nam="+file_.getName());

                int prograss=0;
                while (true) {
                    int bytesRead = is.read(bytes);
                    if (bytesRead < 0) break;
                    bos.write(bytes, 0, bytesRead);
                    prograss=prograss+1;
                    System.out.println(prograss);
                    // Now it loops around to read some more.
                }
                Log.i("ResqtDow","done");
                bos.close();
                clientSocket.close();
                serverSocket.close();


            } catch (IOException e) {
                e.printStackTrace();
            }finally {
                if (serverSocket!=null){
                    try {
                        clientSocket.close();

                    serverSocket.close();
                    } catch (IOException e) {
                    e.printStackTrace();
                }

                }
            }
        //}

    }
}
