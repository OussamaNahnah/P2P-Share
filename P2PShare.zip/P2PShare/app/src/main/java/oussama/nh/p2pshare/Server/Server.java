package oussama.nh.p2pshare.Server;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.AsyncTask;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.ViewGroup;


import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.lang.ref.WeakReference;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import oussama.nh.p2pshare.R;
import oussama.nh.p2pshare.Server.Info.SrvInfo;
import oussama.nh.p2pshare.Server.globaldisc.RecieveMsgSrv;
import oussama.nh.p2pshare.Server.globaldisc.SrvGlobalDisc;
import oussama.nh.p2pshare.Server.localdisc.RecieveLocalMsgsrv;
import oussama.nh.p2pshare.Server.localdisc.SrvLocalDisc;
import oussama.nh.p2pshare.Server.members.MembersObj;
import oussama.nh.p2pshare.Server.shared.RecieveRequestDB;
import oussama.nh.p2pshare.Server.shared.SrvShared;
import oussama.nh.p2pshare.Server.shared.Uploadsrv;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.File_;
import oussama.nh.p2pshare.shared.Request;
import oussama.nh.p2pshare.shared.Utils;

public class Server extends AppCompatActivity {

    SqliteHelper sqliteHelper;
    private static TabLayout tabLayout;
    private static ViewPager viewPager;
    private static ViewPagerAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_server);

        viewPager = (ViewPager) findViewById(R.id.viewpager_srv);
          adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new SrvInfo(), "Info");
        adapter.addFragment(new SrvShared(), "shared");
        adapter.addFragment(new SrvLocalDisc(), "local dis");
        adapter.addFragment(new SrvGlobalDisc(), "global dis");
        viewPager.setAdapter(adapter);
        tabLayout = (TabLayout) findViewById(R.id.tabs_srv);
        tabLayout.setupWithViewPager(viewPager);


        sqliteHelper = new SqliteHelper(getApplicationContext());
        sqliteHelper.addMember(Utils.getIPAddress(true),"Server","ser","00,00");
     /*   try {
while (true){
    Thread t=new Thread(new MulticastDatabase(sqliteHelper));
    t.start();
        Thread.sleep(5000);
}
        } catch (InterruptedException e) {
        e.printStackTrace();
    }*/
        for (int i = 0; i < 10; i++) {
            int y = 2000 + i;
            RecieveRequestObj recieveRequestObj = new RecieveRequestObj(Server.this);
            recieveRequestObj.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, y);
        }
        RecieveFileAdd recieveFileAdd = new RecieveFileAdd(Server.this);
        recieveFileAdd.execute(sqliteHelper);
        Thread send=new Thread(new RecieveMsgSrv(sqliteHelper,Server.this,9994));
        send.start();
        Log.i("rcloclMsg", "s111");
        Thread re=new Thread(new RecieveLocalMsgsrv(sqliteHelper, Server.this,9198));
        re.start();
        Log.i("up1srv", "s111");
        Thread SendFILEforreal=new Thread(new Uploadsrv(Server.this,9190));
        SendFILEforreal.start();
 /*
        multicastDatabase multicastDatabase = new multicastDatabase(Server.this);
        multicastDatabase.execute(sqliteHelper);
       try {
            while (true) {
                Cursor res=sqliteHelper.get_Members();
                if (res.getCount() == 0) {
                    Toast.makeText(getApplicationContext(), "count =0", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "kayan", Toast.LENGTH_LONG).show();
                    while (res.moveToNext()) {
                        membersObjs.add(new MembersObj(res.getString(1),res.getString(3)));

                    }
                }

                Thread.sleep(1);
            }

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
*/

        /**/
        Log.i("udp2", "ooooooooooo");
      /*  RecieveRequestDatabase recieveDatabase = new RecieveRequestDatabase(Server.this);
        recieveDatabase.execute(sqliteHelper);
        */
        Log.i("recRQT", "000000000000000000000");
       Thread receiveRequestDb=new Thread(new RecieveRequestDB(sqliteHelper));
       receiveRequestDb.start();

        Log.i("udp2", "eeeeeeeeee");

       /* BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation_server);
        openFragment(new SrvInfo(), R.id.main_container_srv);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                switch (menuItem.getItemId()) {
                    case R.id.ser_info:
                        openFragment(new SrvInfo(), R.id.main_container_srv);
                        break;
                    case R.id.ser_database:
                        openFragment(new SrvShared(), R.id.main_container_srv);
                        break;
                    case R.id.ser_localdisc:
                        openFragment(new SrvLocalDisc(), R.id.main_container_srv);
                        break;
                    case R.id.ser_globaldisc:
                        openFragment(new SrvGlobalDisc(), R.id.main_container_srv);
                        break;
                }
                return true;
            }
        });*/
    }

    @Override
    public void onBackPressed() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(Server.this);
        builder.setTitle("Exit");
        builder.setMessage("do u wonna to exit");
        builder.setPositiveButton("sure", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                finish();
                System.exit(0);
            }
        });
        builder.setNegativeButton("Not now!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
        //  super.onBackPressed();

    }

    void openFragment(Fragment fragment, int id) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(id, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
 /* public static   void  test(){
        int index = viewPager.getCurrentItem();
        ViewPagerAdapter adapter = ((ViewPagerAdapter)viewPager.getAdapter());
        Log.i("tab", ""+index);

        if (index==0){
            final SrvInfo tabFragment = (SrvInfo) adapter.getFragment(index);

        }else  if (index==1){
            final SrvShared tabFragment = (SrvShared) adapter.getFragment(index);
        }else  if (index==2){
            final SrvLocalDisc tabFragment = (SrvLocalDisc) adapter.getFragment(index);
        }else if (index==3){
            final SrvInfo SrvGlobalDisc = (SrvInfo) adapter.getFragment(index);
        }
      }
*/
    private class RecieveRequestObj extends AsyncTask<Object, Object, String> {
        String answer = "";
        Request request = null;
        private WeakReference<Server> activityWeakReference;

        RecieveRequestObj(Server activity) {
            activityWeakReference = new WeakReference<Server>(activity);
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(Object... objects) {
            int prt = (Integer) objects[0];
            Log.i("udp", "yy=" + prt);
            while (true) {
                DatagramPacket packet;
                DatagramSocket socket = null;
                try {
                    socket = new DatagramSocket(prt);
                    byte[] data = new byte[4];
                    packet = new DatagramPacket(data, data.length);
                    Log.i("udp", " ,,,,,,,,,,,");
                    socket.receive(packet);
                    int len = 0;
                    // byte[] -> int
                    for (int i = 0; i < 4; ++i) {
                        len |= (data[3 - i] & 0xff) << (i << 3);
                    }
                    // now we know the length of the payload
                    byte[] buffer = new byte[len];
                    packet = new DatagramPacket(buffer, buffer.length);
                    socket.receive(packet);
                    ByteArrayInputStream baos = new ByteArrayInputStream(buffer);
                    ObjectInputStream oos = new ObjectInputStream(baos);
                    request = (Request) oos.readObject();

                    ///////////////
                    byte[] answer = new byte[4];
                    Log.i("udp", " ,,,,,,,,,,,");
                    InetAddress client = InetAddress.getByName(request.getPair_ip());
                    Log.i("udp", " _________________getM");
                    packet = new DatagramPacket(answer, 4, client, prt);
                    Log.i("udp", " getMtttttttttttttttttttttsg");
                    socket.send(packet);
                    Log.i("udp", " nnngkjksksgfiidk" + request.getMsg());
                    socket.close();
                    socket = new DatagramSocket();


                    String string = "okyy";
                    Log.i("udp", "  " + string);
                    byte ms1[] = string.getBytes(StandardCharsets.UTF_8);
                    packet = new DatagramPacket(ms1, ms1.length, client, 7000);
                    Log.i("udp", " tqq");
                    socket.send(packet);
                    Log.i("udp", " done");
                    onProgressUpdate(request);
/*
                Log.i("udp"," getPair_name"+request.getPair_name());
                Log.i("udp"," getPair_ip"+request.getPair_ip());
                Log.i("udp"," getMsg"+request.getMsg());
                Log.i("udp"," getServer_ip"+request.getServer_ip());
                Log.i("udp"," getPort"+request.getPort());
                Log.i("udp"," getPassword"+request.getPassword()); */
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (socket != null) {
                        socket.close();
                    }
                }
            }

        }


        @Override
        protected void onProgressUpdate(Object... values) {
            super.onProgressUpdate(values);
            Request request = (Request) values[0];
            Server activity = activityWeakReference.get();
            if (activity == null || activity.isFinishing()) {
                return;
            }
            Log.i("udp", " getPair_name" + request.getPair_name());
            Log.i("udp", " getPair_ip" + request.getPair_ip());
            Log.i("udp", " getMsg" + request.getMsg());
            Log.i("udp", " getServer_ip" + request.getServer_ip());
            Log.i("udp", " getPort" + request.getPort());
            Log.i("udp", " getPassword" + request.getPassword());
            Log.i("udp", " data:" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date()));
            SqliteHelper sqliteHelper = new SqliteHelper(activity);
            Cursor cursor = sqliteHelper.existMember(request.getPair_ip());
            Log.i("udp", " 1:" + cursor.getCount());
            if (cursor.moveToFirst() && cursor.getCount() > 0) {
                if (sqliteHelper.updateMember(request.getPair_ip(), "ok",
                        new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date())))
                    Log.i("udp", " curser updated");
                //    answer = "updated";
            } else {
                Log.i("udp", " not same");
                //if (Integer.parseInt(SrvInfo.srv_password.getText().toString()) == request.getPassword()) {
                Log.i("udp", " samepassword");
                sqliteHelper.addMember(request.getPair_ip(),
                        request.getPair_name(),
                        "yes",

                        new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date()));
                Log.i("udp", " curser inserted");
              //  openFragment(new SrvInfo(), R.id.main_container_srv);
                //   answer = "inserted";
                //  SrvInfo.srv_password.setText("" + activity.getPort());
                //   }


            }

        }

    /*    @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Server activity = activityWeakReference.get();
            if (activity == null || activity.isFinishing()) {
                return;
            }
            RecieveRequestObj recieveRequestObj = new RecieveRequestObj(Server.this);
            recieveRequestObj.execute( 1500);

        }*/


    }

    private static class RecieveRequestDatabase extends AsyncTask<Object, Object, Object> {

        private WeakReference<Server> activityWeakReference;

        RecieveRequestDatabase(Server activity) {
            activityWeakReference = new WeakReference<Server>(activity);
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(Object... objects) {
            SqliteHelper sqliteHelper = (SqliteHelper) objects[0];
            Log.i("udp2", "000000000000000000000");
            while (true) {
                Log.i("udp2", "wssal");


                DatagramSocket socket = null;
                try {
                    socket = new DatagramSocket(3000);
                    byte msg1[] = new byte[20];
                    DatagramPacket datagramPacket = new DatagramPacket(msg1, msg1.length);

                    Log.i("udp2", "rah yab3ath");
                    socket.receive(datagramPacket);
                    String string = new String(msg1, StandardCharsets.UTF_8);
                    Log.i("udp2", "wsal:" + string);
                    /////////////////////////////////////////////////
                    //************************principal**********************
                    // onProgressUpdate();
                    Log.i("udp2", "x:");
                    try {

                        ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                        ObjectOutput oo = new ObjectOutputStream(bStream);
                        Log.i("udp2", "x2");
                        Cursor res = sqliteHelper.get_Members();
                        Log.i("udp2", "x3");
                        ArrayList<MembersObj> membersObjs = new ArrayList<>();

                        if (res.getCount() == 0) {
                            Log.i("udp2", "count 0");
                        } else {
                            Log.i("udp2", "count +0");
                            while (res.moveToNext()) {
                                membersObjs.add(new MembersObj(res.getString(1),res.getString(2),res.getString(3), res.getString(4)));

                                Log.i("udp2", "member"+res.getString(1));
                            }
                        }
                        Log.i("udp2", "count +0");
                        oo.writeObject(membersObjs);
                        Log.i("udp2", "x4");
                        oo.close();
                        Log.i("udp2", "x5");

                        byte[] serializedMessage = bStream.toByteArray();
                        Log.i("udp2", "x6");
                        Log.i("udp2", "serializedMessage:" + serializedMessage.length);
                        DatagramPacket packet = new DatagramPacket(serializedMessage, serializedMessage.length,
                                InetAddress.getByName("224.0.0.7"), 9969);
                        Log.i("udp2", "x7");
                        socket.send(packet);
                        Log.i("udp2", "x8");
                        socket.close();
                        Log.i("udp2", "x9");
                    } catch (UnknownHostException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
//                ByteArrayOutputStream bStream = new ByteArrayOutputStream();
//                ObjectOutput oo = new ObjectOutputStream(bStream);
//                oo.writeObject(members);
//                oo.close();
//
//                byte[] serializedMessage = bStream.toByteArray();
//                Log.i("udp2","serializedMessage:"+serializedMessage.length);
//                DatagramPacket packet = new DatagramPacket(serializedMessage, serializedMessage.length,
//                        InetAddress.getByName("224.0.0.1"),9999);
//                socket.send(packet);
//                socket.close();
//*********************************************************
// ************************principal**********************
              /*   socket = new DatagramSocket();
                String msg="oussama";
                byte buff[] = msg.getBytes();
                DatagramPacket packet = new DatagramPacket(buff, buff.length,
                        InetAddress.getByName("224.0.0.1"),9999);
                socket.send(packet);
                socket.close();*/
//*********************************************************
                } catch (SocketException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (socket != null) {
                        socket.close();
                    }
                }

            }
            //  return null;
        }

        @Override
        protected void onProgressUpdate(Object... values) {
            super.onProgressUpdate(values);
            Server activity = activityWeakReference.get();
            if (activity == null || activity.isFinishing()) {
                return;
            }


        }


    }

    private static class multicastDatabase extends AsyncTask<Object, Object, Object> {

        private WeakReference<Server> activityWeakReference;

        multicastDatabase(Server activity) {
            activityWeakReference = new WeakReference<Server>(activity);
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(Object... objects) {
            Log.i("udp2", "xv");

            SqliteHelper sqliteHelper = (SqliteHelper) objects[0];

            Log.i("udp2", "xvv");

            DatagramSocket socket = null;
            try {
                socket = new DatagramSocket(3000);
                ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                ObjectOutput oo = new ObjectOutputStream(bStream);
                Log.i("udp2", "x::");
                oo.writeObject(sqliteHelper.get_Members());
                oo.close();
                Log.i("udp2", "x:::");

                byte[] serializedMessage = bStream.toByteArray();
                Log.i("udp2", "serializedMessage:" + serializedMessage.length);
                DatagramPacket packet = new DatagramPacket(serializedMessage, serializedMessage.length,
                        InetAddress.getByName("224.0.0.1"), 9999);
                socket.send(packet);
                socket.close();
            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Object... values) {
            super.onProgressUpdate(values);
            Server activity = activityWeakReference.get();
            if (activity == null || activity.isFinishing()) {
                return;
            }


        }


    }


    private static class RecieveFileAdd extends AsyncTask<Object, Object, Object> {

        private WeakReference<Server> activityWeakReference;

        RecieveFileAdd(Server activity) {
            activityWeakReference = new WeakReference<Server>(activity);
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(Object... objects) {
            SqliteHelper sqliteHelper = (SqliteHelper) objects[0];
            try {
                Log.i("shared", "s1");
                while (true) {
                    DatagramSocket socket = new DatagramSocket(9998);
                    byte[] buf = new byte[256];Log.i("shared", "s11");
                    DatagramPacket packet = new DatagramPacket(buf, buf.length);
                    Log.i("shared", "s111");
                    socket.receive(packet);
                    Log.i("shared", "s2");
                    socket.close();
                    ObjectInputStream iStream = new ObjectInputStream(new ByteArrayInputStream(buf));
                    File_ file_ = (File_) iStream.readObject();
                    Log.i("shared", "name" + file_.getName());
                    Log.i("shared", "owner" + file_.getOwner());
                    Log.i("shared", "type" + file_.getType());
                    Log.i("shared", "size" + file_.getSize());
                    sqliteHelper.addFile(file_.getOwner()
                            , file_.getName()
                            , file_.getPath()
                            , file_.getType()
                            , file_.getSize());
                    ////////////////////////////////////////////////
                    Log.i("shared", "x:");
                    try {
                        ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                        ObjectOutput oo = new ObjectOutputStream(bStream);
                        Log.i("shared", "x2");
                        Cursor res = sqliteHelper.get_Files();
                        Log.i("shared", "x3");
                        ArrayList<File_> file_s = new ArrayList<>();
                        if (res.getCount() == 0) {
                            Log.i("shared", "count 0");
                        } else {
                            Log.i("shared", "count +0");
                            while (res.moveToNext()) {
                                file_s.add(new File_(res.getString(1), res.getString(2), res.getString(3), res.getString(4), res.getString(5)));
                            }
                        }
                        oo.writeObject(file_s);
                        Log.i("shared", "x4");
                        oo.close();
                        Log.i("shared", "x5");

                        byte[] serializedMessage = bStream.toByteArray();
                        Log.i("shared", "x6");
                        Log.i("shared", "serializedMessage:" + serializedMessage.length);
                        packet = new DatagramPacket(serializedMessage, serializedMessage.length,
                                InetAddress.getByName("224.0.0.2"), 9996);
                        Log.i("shared", "x7");
                        socket.close();
                        socket =new DatagramSocket();
                        socket.send(packet);
                        Log.i("udp2", "x8");
                        socket.close();
                        Log.i("udp2", "x9");
                    } catch (UnknownHostException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    ///////////////////////////////////////////////////////////////////
                    iStream.close();
                    socket.close();
                }

            } catch (SocketException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            return null;
        }

    }


    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();

        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
/////////////////////////////////////////////
        HashMap<Integer, Fragment> mPageReferenceMap = new HashMap<>();
        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            Fragment fragment = (Fragment) super.instantiateItem(container, position);
            mPageReferenceMap.put(position, fragment);
            return fragment;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            super.destroyItem(container, position, object);
            mPageReferenceMap.remove(position);
        }
        public Fragment getFragment(int key) {
            return mPageReferenceMap.get(key);
        }



    }

    // public static ViewPager viewPager; //GLOBAL
    // public static HomePager adapter; //GLOBAL
    //adapter = new HomePager(getSupportFragmentManager(), hometabLayout.getTabCount()); //onCreate section

    public static void _openSIGNIN() // Create this static method
    {
        viewPager.setCurrentItem(0);
    }

    public static void _openSIGNUP() // Create this static method
    {
        viewPager.setCurrentItem(1);
    }

    public static void updatetablayout(){
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
    }public static void updatetablayout_globaldis(){
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        viewPager.setCurrentItem(2);
    }

}