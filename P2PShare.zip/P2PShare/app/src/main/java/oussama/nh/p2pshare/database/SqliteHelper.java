package oussama.nh.p2pshare.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

public class SqliteHelper extends SQLiteOpenHelper {
    private static final String DATABASE = "P2PShare.db";
    private static final int DATABASE_VERSION = 1;
    ///////////////////////////////////////
    private static final String MEMBERS = "members";
    private static  String MEMBER_ID = "member_id";
    private static  String MEMBER_IP = "member_ip";
    private static  String MEMBER_NAME = "member_name";
    private static  String MEMBER_ACTIVE = "member_active";
    private static  String MEMBER_LAST_TIME = "member_last_time";
    ///////////////////////////////////////
    private static final String SERVER = "server";
    private static  String SERVER_ID = "server_id";
    private static  String SERVER_IP = "server_ip";
    private static  String SERVER_PORT = "server_port";

    ////////////////////////////////
    private static final String FILES= "files";
    private static  String FILE_ID = "file_id";
    private static  String FILE_OWNER = "file_owner";
    private static  String FILE_NAME = "file_name";
    private static  String FILE_PATH = "file_path";
    private static  String FILE_TYPE = "file_type";
    private static  String FILE_SIZE = "file_size";
    ///////////////////////////////
    private static final String LOCAL_DISC = "local_disc";
    private static  String LOCAL_DISC_SENDER = "local_disc_sender";
    private static  String LOCAL_DISC_RECIEVER = "local_disc_reciever";
    private static  String LOCAL_DISC_MSG = "local_disc_msg";
    private static  String LOCAL_DISC_time = "local_disc_time";
    ////////////////////////////////
    private static final String GLOBAL_DISC = "global_disc";
    private static  String GLOBAL_DISC_SENDER = "global_disc_sender";
    private static  String GLOBAL_DISC_MSG = "global_disc_msg";
    private static  String GLOBAL_DISC_time = "global_disc_time";
    ////////////////////////////////
    private static final String SETTINGS = "settings";
    private static  String PORT_SERVER = "port_server";
    private static  String PORT_FILE = "port_file";
    private static  String PORT_LOCAL_DISC = "port_local_disc";
    private static  String PORT_GLOBAL_DISC = "port_global_disc";



    public SqliteHelper(  Context context) {
        super(context, DATABASE, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " + MEMBERS + "("+MEMBER_ID+" INTEGER PRIMARY KEY AUTOINCREMENT ,"+MEMBER_IP+" text,"+
                MEMBER_NAME+" text,"+MEMBER_ACTIVE+" text,"+MEMBER_LAST_TIME+" text) ");
        sqLiteDatabase.execSQL("CREATE TABLE " + SERVER + "("+SERVER_ID+" INTEGER PRIMARY KEY AUTOINCREMENT ,"+SERVER_IP+" text,"+
                SERVER_PORT+" text) ");
        sqLiteDatabase.execSQL("CREATE TABLE " + FILES + "("+FILE_ID+" INTEGER PRIMARY KEY AUTOINCREMENT ,"+FILE_OWNER+" text,"+FILE_NAME+" text,"+FILE_PATH+" text,"+
                FILE_TYPE+" text,"+FILE_SIZE+" text) ");
        sqLiteDatabase.execSQL("CREATE TABLE " + LOCAL_DISC + "("+LOCAL_DISC_SENDER+" text,"+LOCAL_DISC_RECIEVER+" text,"+
                LOCAL_DISC_MSG+" text,"+LOCAL_DISC_time+" text) ");
        sqLiteDatabase.execSQL("CREATE TABLE " + GLOBAL_DISC + "("+GLOBAL_DISC_SENDER+" text,"+
                GLOBAL_DISC_MSG+" text,"+GLOBAL_DISC_time+" text) ");
        sqLiteDatabase.execSQL("CREATE TABLE " + SETTINGS + "("+PORT_SERVER+" INTEGER PRIMARY KEY AUTOINCREMENT ,"+PORT_FILE+" text,"+
                PORT_LOCAL_DISC+" text,"+PORT_GLOBAL_DISC+" text) ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL(" DROP TABLE IF EXISTS " + MEMBERS);
        sqLiteDatabase.execSQL(" DROP TABLE IF EXISTS " + SERVER);
        sqLiteDatabase.execSQL(" DROP TABLE IF EXISTS " + FILES);
        sqLiteDatabase.execSQL(" DROP TABLE IF EXISTS " + LOCAL_DISC);
        sqLiteDatabase.execSQL(" DROP TABLE IF EXISTS " + GLOBAL_DISC);
        sqLiteDatabase.execSQL(" DROP TABLE IF EXISTS " + SETTINGS);
    }
    public boolean addMember(String ip, String name, String active, String lasttime) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(MEMBER_IP, ip);
        cv.put(MEMBER_NAME, name);
        cv.put(MEMBER_ACTIVE, active);
        cv.put(MEMBER_LAST_TIME, lasttime);

        long results = db.insert(MEMBERS, null, cv);
        db.close();
        if (results == -1) return false;
        else return true;
    }    public boolean addServer(String ip, String port) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(SERVER_IP, ip);
        cv.put(SERVER_PORT, port);
        long results = db.insert(SERVER, null, cv);
        db.close();
        if (results == -1) return false;
        else return true;
    }
    public boolean addFile(String owner, String name, String path, String type, String size) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(FILE_OWNER, owner);
        cv.put(FILE_NAME, name);
        cv.put(FILE_PATH, path);
        cv.put(FILE_TYPE, type);
        cv.put(FILE_SIZE, size);
        long results = db.insert(FILES, null, cv);
        db.close();
        if (results == -1) return false;
        else return true;
    } public void addGlobalDisc(String sender, String txt) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(GLOBAL_DISC_SENDER, sender);
        cv.put(GLOBAL_DISC_MSG, txt);
        cv.put(GLOBAL_DISC_time, "time");
        long results = db.insert(GLOBAL_DISC, null, cv);
        db.close();
      //  if (results == -1) return false;
        //else return true;
    } public void addLocalDisc(String sender,String rec, String txt) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(LOCAL_DISC_SENDER, sender);
        cv.put(LOCAL_DISC_RECIEVER, rec);
        cv.put(LOCAL_DISC_MSG, txt);
        cv.put(LOCAL_DISC_time, "time");
        long results = db.insert(LOCAL_DISC, null, cv);
        db.close();
      //  if (results == -1) return false;
        //else return true;
    }
    public Cursor existMember(String ip) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM "+MEMBERS+" WHERE "+MEMBER_IP+" = ? ", new String[] {ip});
        return c;
    }
    public Cursor portMemberused(String port) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM "+MEMBERS+" WHERE "+MEMBER_ID+" = ? ", new String[] {port});
        return c;
    }
    public boolean updateMember(String ip, String active,  String lasttime) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(MEMBER_ACTIVE, active);
        cv.put(MEMBER_LAST_TIME, lasttime);
        long results = db.update(MEMBERS, cv, MEMBER_IP+" = ? ", new String[]{ip});
        db.close();
        if (results == -1) return false;
        else return true;

    }
    public Cursor get_Members() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + MEMBERS, null);
        return c;
    }
    public Cursor get_Server() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + SERVER, null);
        return c;
    }
    public Cursor get_Files() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + FILES, null);
        return c;
    }   public Cursor getGlobalDisc() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + GLOBAL_DISC, null);
        return c;
    }  public Cursor getlocaldisc() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + LOCAL_DISC, null);
        return c;
    }
    public boolean delete_Server() {
        SQLiteDatabase db = this.getReadableDatabase();
        db.execSQL("delete from "+ SERVER);
        return true;
    }    public boolean delete_Member() {
        SQLiteDatabase db = this.getReadableDatabase();
        db.execSQL("delete from "+ MEMBERS);
        return true;
    }
public void delete_Files() {
        SQLiteDatabase db = this.getReadableDatabase();
        db.execSQL("delete from "+ FILES);

    }
    public void delete_all() {
        SQLiteDatabase db = this.getReadableDatabase();
        db.execSQL("delete from "+ MEMBERS);
     //   db.execSQL("delete from "+ SERVER);
        db.execSQL("delete from "+ FILES);
        db.execSQL("delete from "+ LOCAL_DISC);
        db.execSQL("delete from "+ GLOBAL_DISC);
//        db.execSQL("delete from "+ SETTINGS);

    }


}
