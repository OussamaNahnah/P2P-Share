package oussama.nh.p2pshare.Server.localdisc;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;

import oussama.nh.p2pshare.Pair.Pair;
import oussama.nh.p2pshare.R;
import oussama.nh.p2pshare.Server.Server;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.MSG;
import oussama.nh.p2pshare.shared.Utils;

public class RecieveLocalMsgsrv implements Runnable{
    SqliteHelper sqliteHelper;
    Server server;
    int port;

    public RecieveLocalMsgsrv(SqliteHelper sqliteHelper, Server server, int port) {
        this.sqliteHelper = sqliteHelper;
        this.server = server;
        this.port = port;
    }

    @Override
    public void run() {


        Log.i("rcloclMsg", "s1");
        while (true) {
            DatagramSocket socket=null;
            try {


                socket   = new DatagramSocket(port);
                byte[] buf = new byte[256];
                Log.i("rcloclMsg", "s11");
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                Log.i("rcloclMsg", "s111");
                socket.receive(packet);
                Log.i("rcloclMsg", "s2");
                socket.close();
                ObjectInputStream iStream = new ObjectInputStream(new ByteArrayInputStream(buf));
                MSG msg = (MSG) iStream.readObject();
                Log.i("rcloclMsg","count: " + msg.getIp());
                Log.i("rcloclMsg","count: " + msg.getTxt());

                sqliteHelper.addLocalDisc(msg.getIp(), Utils.getIPAddress(true),msg.getTxt());
                server.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        NotificationManager mNotificationManager;

                        NotificationCompat.Builder mBuilder =
                                new NotificationCompat.Builder(server.getApplicationContext(), msg.getIp());
                        Intent ii = new Intent(server.getApplicationContext().getApplicationContext(), Pair.class);
                        PendingIntent pendingIntent = PendingIntent.getActivity(server.getApplicationContext(), 0, ii, 0);

                        NotificationCompat.BigTextStyle bigText = new NotificationCompat.BigTextStyle();
                        bigText.bigText(msg.getTxt());
                        bigText.setBigContentTitle(msg.getIp());
                        bigText.setSummaryText(msg.getIp());

                        mBuilder.setContentIntent(pendingIntent);
                        mBuilder.setSmallIcon(R.mipmap.ic_launcher_round);
                        mBuilder.setContentTitle("Your Title");
                        mBuilder.setContentText("Your text");
                        mBuilder.setPriority(NotificationCompat.PRIORITY_MAX);
                        mBuilder.setStyle(bigText);
                        mBuilder.setAutoCancel(true);

                        mNotificationManager =
                                (NotificationManager) server.getApplicationContext().getSystemService(server.getApplicationContext().NOTIFICATION_SERVICE);

// === Removed some obsoletes
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        {
                            String channelId = "Your_channel_id";
                            NotificationChannel channel = new NotificationChannel(
                                    channelId,
                                    "Channel human readable title",
                                    NotificationManager.IMPORTANCE_HIGH);
                            mNotificationManager.createNotificationChannel(channel);
                            mBuilder.setChannelId(channelId);
                        }

                        mNotificationManager.notify(0, mBuilder.build());

                    }
                });

                iStream.close();
                socket.close();

            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }finally {
                if (socket!=null)socket.close();
            }
        }
    }

}
