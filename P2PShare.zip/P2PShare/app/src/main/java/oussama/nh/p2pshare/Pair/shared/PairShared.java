package oussama.nh.p2pshare.Pair.shared;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.lang.ref.WeakReference;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketException;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import oussama.nh.p2pshare.Pair.Pair;
import oussama.nh.p2pshare.Pair.localdisc.RecieveLocalMsgPair;
import oussama.nh.p2pshare.R;
import oussama.nh.p2pshare.Server.Server;
import oussama.nh.p2pshare.Server.members.MembersAdapter;
import oussama.nh.p2pshare.Server.members.MembersObj;
import oussama.nh.p2pshare.Server.shared.SrvSharedAdapter;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.File_;
import oussama.nh.p2pshare.shared.PathUtil;
import oussama.nh.p2pshare.shared.Utils;


public class PairShared extends Fragment {


    static RecyclerView recyclerView;
    static SrvSharedAdapter srvSharedAdapter;
    static ArrayList<File_> file_s;
     SqliteHelper sqliteHelper;

     /////////////////////////////////////////////share
     public static final int PICKFILE_RESULT_CODE = 1;
    private Uri fileUri;
    private String filePath;
    public String ip_server;

    public PairShared() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root= inflater.inflate(R.layout.fragment_pair_shared, container, false);
        Log.i("nahnah","PairShared ");
        //Button pair_updte_layout=root.findViewById(R.id.pair_updte_layout);
     /*   pair_updte_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.main_container_pair, new PairShared());
                transaction.addToBackStack("oussama");
                transaction.commit();
            }
        });*/

       /* Thread recieve_files_db=new Thread(new RecieveFilesDB(sqliteHelper));
        Log.i("shared","PairShared ");
        recieve_files_db.start();
        Log.i("shared","PairShared ");
        /////////////////
     /*   Log.i("shared","sending ...");
        SendFileAdd sendFileAdd=new SendFileAdd(PairShared.this);
        sendFileAdd.execute(new File_(Utils.getIPAddress(true),"path","type",""+"size"),ip_server);
     Log.i("shared","sended"); */
        /////////

        sqliteHelper=new SqliteHelper(root.getContext());

        sqliteHelper=new SqliteHelper(getContext());
        Cursor cursorServer=sqliteHelper.get_Server();
        if (cursorServer.getCount()!=0){
            if (cursorServer.moveToFirst()){
                ip_server=cursorServer.getString(1);

            }}else {
            Toast.makeText(getContext(),"Problem there is no Server",Toast.LENGTH_SHORT).show();
        }

        Button share_file=root.findViewById(R.id.pair_share_file);
        share_file.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent chooseFile = new Intent(Intent.ACTION_GET_CONTENT);
                chooseFile.setType("*/*");
                chooseFile = Intent.createChooser(chooseFile, "Choose a file");
                startActivityForResult(chooseFile, PICKFILE_RESULT_CODE);


            }
        });












        file_s  = new ArrayList<>();
        recyclerView =root. findViewById(R.id.pair_shared_recycle);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));



        update_rec();

       // RecieveDatabase recieveDatabase=new RecieveDatabase(PairShared.this);
       // recieveDatabase.execute();

        return root;
    }
    @Override

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case PICKFILE_RESULT_CODE:
                if (resultCode == -1) {
                    fileUri = data.getData();
                    filePath = fileUri.getPath();
                    Log.i("shared","url:"+filePath);
                    Toast.makeText(getContext(),"url:"+filePath,Toast.LENGTH_SHORT).show();
                  //  tvItemPath.setText(filePath);

                    //***********************
                    long size=0;

                    ContentResolver cR = getContext().getContentResolver();
                    MimeTypeMap mime = MimeTypeMap.getSingleton();
                    String type = mime.getExtensionFromMimeType(cR.getType(fileUri));
                    Log.i("shared","type:"+type);
                    try {
                          size= cR.openFileDescriptor(fileUri,"r").getStatSize();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    Log.i("shared","size:"+size);
                    String path = fileUri.getPath();
                    Log.i("shared","path:"+path);
                  /*  SendFileAdd sendFileAdd=new SendFileAdd(PairShared.this);
                    Log.i("shared","sendig...:");
                    sendFileAdd.execute(//AsyncTask.THREAD_POOL_EXECUTOR,
                             new File_(Utils.getIPAddress(true),path,type,""+size),ip_server);*/




                    String filePathh=null;
                    try {
                        filePathh= PathUtil.getPath(getContext(),fileUri);
                        Log.i("shared", "fffffffffffffffffff;"+filePathh);
                    } catch (URISyntaxException e) {
                        e.printStackTrace();
                    }
                    File file = null;
                    try {


                        file = new File(filePathh);
                        if(file.exists()) {
                            Log.i("shared", "exict");
                        }else    Log.i("shared", "not exict");

                    }catch (Exception e){
                        Log.i("shared","eer"+e.getMessage());
                    }
                    File_ ff=new File_(Utils.getIPAddress(true),file.getName(),fileUri.getPath(),type,""+size);
                    Thread sendfile=new Thread(new SendFile( ff,ip_server));
                    sendfile.start();
                    sqliteHelper.addFile(Utils.getIPAddress(true),file.getName(),path,type,""+size);
                  //  file_s.clear();
                    update_rec();
                    Log.i("shared","sended");
                }
                break;
        }
    }

void  update_rec(){

    Cursor res=sqliteHelper.get_Files();
    if (res.getCount() == 0) {
        Toast.makeText(recyclerView.getContext(), "count =0", Toast.LENGTH_LONG).show();
    } else {
        // Toast.makeText(recyclerView.getContext(), "kayan", Toast.LENGTH_LONG).show();
        while (res.moveToNext()) {

            file_s.add(new File_(res.getString(1),res.getString(2),res.getString(3),res.getString(4),res.getString(5)));

        }
        Toast.makeText(recyclerView.getContext(), "count =",res.getCount()).show();
    }
    srvSharedAdapter = new SrvSharedAdapter( getContext(), file_s);
    srvSharedAdapter.setClickListener(new SrvSharedAdapter.ItemClickListener() {
        @Override
        public void onItemClick(View view, int position) {
            Toast.makeText(getContext(), "You clicked " + srvSharedAdapter.getItem(position) + " on row number " + position, Toast.LENGTH_SHORT).show();
            Log.i("ResqtDow", "s111");
            Thread send=new Thread(new RequestDownload((Pair) getActivity(),9190,srvSharedAdapter.getItem(position)));
            send.start();
        }
    });

    recyclerView.setAdapter(srvSharedAdapter);
}
  /*  private String getRealPathFromURI(Uri contentURI) {
        String result;
        Cursor cursor = getContext().getContentResolver().query(contentURI, null, null, null, null);
        if (cursor == null) { // Source is Dropbox or other similar local file path
            result = contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            result = cursor.getString(idx);
            cursor.close();
        }
        return result;
    }*/
 /* public static String getFileNameByUri(Context context, Uri uri)
  {
      String fileName="unknown";//default fileName
      Uri filePathUri = uri;
      if (uri.getScheme().toString().compareTo("content")==0)
      {
          Cursor cursor = context.getContentResolver().query(uri, null, null, null, null);
          if (cursor.moveToFirst())
          {
              int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);//Instead of "MediaStore.Images.Media.DATA" can be used "_data"
              filePathUri = Uri.parse(cursor.getString(column_index));
              fileName = filePathUri.getLastPathSegment().toString();
          }
      }
      else if (uri.getScheme().compareTo("file")==0)
      {
          fileName = filePathUri.getLastPathSegment().toString();
      }
      else
      {
          fileName = fileName+"_"+filePathUri.getLastPathSegment();
      }
      return fileName;
  }*/

}