package oussama.nh.p2pshare.Pair.globaldisc;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.ArrayList;

import oussama.nh.p2pshare.Pair.Pair;
import oussama.nh.p2pshare.R;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.File_;
import oussama.nh.p2pshare.shared.MSG;

public class RecieveMsgPair implements Runnable{
SqliteHelper sqliteHelper;
Pair pair;
int port;


    public RecieveMsgPair(SqliteHelper sqliteHelper, Pair pair, int port) {
        this.sqliteHelper = sqliteHelper;
        this.pair = pair;
        this.port = port;
    }

    @Override
    public void run() {
        try {
            Log.i("recmsgp","creceive shared ");
            //******************principal**********************
            while(true)
            {   MulticastSocket socket = null;
            socket = new MulticastSocket(port);
            Log.i("recmsgp",",, ");
            InetAddress group = InetAddress.getByName("224.0.0.3");
            Log.i("recmsgp",",,, ");
            socket.joinGroup(group);
            DatagramPacket packet;
            Log.i("recmsgp",",,p ");
            byte[] buf = new byte[2048];
            ObjectInputStream iStream;
            Log.i("recmsgp",",,kp ");
            packet = new DatagramPacket(buf, buf.length);
            Log.i("recmsgp",",,àp ");
            Log.i("recmsgp",",,pp ");
                socket.receive(packet);
                Log.i("recmsgp",",,ppp ");
                iStream = new ObjectInputStream(new ByteArrayInputStream(buf));
               MSG msg = (MSG) iStream.readObject();
                Log.i("recmsgp","count: " + msg.getIp());
                Log.i("recmsgp","count: " + msg.getTxt());

                sqliteHelper.addGlobalDisc(msg.getIp(),msg.getTxt());
                pair.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        NotificationManager mNotificationManager;

                        NotificationCompat.Builder mBuilder =
                                new NotificationCompat.Builder(pair.getApplicationContext(), "notify_001");
                        Intent ii = new Intent(pair.getApplicationContext().getApplicationContext(), Pair.class);
                        PendingIntent pendingIntent = PendingIntent.getActivity(pair.getApplicationContext(), 0, ii, 0);

                        NotificationCompat.BigTextStyle bigText = new NotificationCompat.BigTextStyle();
                        bigText.bigText(msg.getTxt());
                        bigText.setBigContentTitle("global disc");
                        bigText.setSummaryText("global disc");

                        mBuilder.setContentIntent(pendingIntent);
                        mBuilder.setSmallIcon(R.mipmap.ic_launcher_round);
                        mBuilder.setContentTitle("Your Title");
                        mBuilder.setContentText("Your text");
                        mBuilder.setPriority(NotificationCompat.PRIORITY_MAX);
                        mBuilder.setStyle(bigText);
                        mBuilder.setAutoCancel(true);

                        mNotificationManager =
                                (NotificationManager) pair.getApplicationContext().getSystemService(pair.getApplicationContext().NOTIFICATION_SERVICE);

// === Removed some obsoletes
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        {
                            String channelId = "Your_channel_id";
                            NotificationChannel channel = new NotificationChannel(
                                    channelId,
                                    "Channel human readable title",
                                    NotificationManager.IMPORTANCE_HIGH);
                            mNotificationManager.createNotificationChannel(channel);
                            mBuilder.setChannelId(channelId);
                        }

                        mNotificationManager.notify(0, mBuilder.build());

                    }
                });

                iStream.close();
                socket.leaveGroup(group);
                socket.close();
        }

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


}
