package oussama.nh.p2pshare.Pair;

import android.util.Log;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;

public class SendRequestDb implements Runnable {
    String ip_server;

    public SendRequestDb(String ip_server) {
        this.ip_server = ip_server;
    }

    @Override
    public void run() {
        Log.i("Rqt", "request");

        DatagramPacket send_;
        DatagramSocket socket = null;
        Log.i("Rqt", "ab3athli db yar7am book");
        Log.i("Rqt", "haho ip server "+ip_server);
        try {
            String string = "db";
            byte msg1[] = string.getBytes(StandardCharsets.UTF_8);
            socket = new DatagramSocket();
            Log.i("Rqt", "haw rah yab3ath");
            send_ = new DatagramPacket(msg1, msg1.length, InetAddress.getByName(ip_server), 3000);

            socket.send(send_);
            Log.i("Rqt", "b3athdeja");
        } catch (UnknownHostException | SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (socket != null) {
                socket.close();
            }
        }



    }
}
