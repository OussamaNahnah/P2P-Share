package oussama.nh.p2pshare.shared;

import java.io.Serializable;

public class File_ implements Serializable {
    String owner;
    String name;
    String path;
    String type;
    String size;
    String requster;

    public File_(String owner, String name, String path, String type, String size) {
        this.owner = owner;
        this.name = name;
        this.path = path;
        this.type = type;
        this.size = size;
    }

    public String getOwner() {
        return owner;
    }

    public String getName() {
        return name;
    }

    public String getPath() {
        return path;
    }

    public String getType() {
        return type;
    }

    public String getSize() {
        return size;
    }

    public String getRequster() {
        return requster;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public void setRequster(String requster) {
        this.requster = requster;
    }
}
/*
    private static  String FILE_ID = "file_id";
    private static  String FILE_OWNER = "file_owner";
    private static  String FILE_NAME = "file_name";
    private static  String FILE_TYPE = "file_type";
    private static  String FILE_SIZE = "file_size";
 */