package oussama.nh.p2pshare.shared;

import java.io.Serializable;

public class MSG implements Serializable {
    String ip;
    String reciver;
    String txt;

    public MSG(String ip, String reciver, String txt) {
        this.ip = ip;
        this.reciver = reciver;
        this.txt = txt;
    }

    public MSG(String ip, String txt) {
        this.ip = ip;
        this.txt = txt;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getReciver() {
        return reciver;
    }

    public void setReciver(String reciver) {
        this.reciver = reciver;
    }

    public String getTxt() {
        return txt;
    }

    public void setTxt(String txt) {
        this.txt = txt;
    }
}
