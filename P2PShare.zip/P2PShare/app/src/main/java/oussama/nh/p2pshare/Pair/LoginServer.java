package oussama.nh.p2pshare.Pair;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.ref.WeakReference;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import oussama.nh.p2pshare.R;
import oussama.nh.p2pshare.Server.Server;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.Request;
import oussama.nh.p2pshare.shared.Utils;

public class LoginServer extends AppCompatActivity {
EditText srv_ip;
EditText srv_passord;
SqliteHelper sqliteHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_server);
        srv_ip=findViewById(R.id.srv_ip);
        srv_passord=findViewById(R.id.srv_passord);
        sqliteHelper=new SqliteHelper(getApplicationContext());
       Cursor cur= sqliteHelper.get_Server();
       if (cur.getCount()!=0){
           Log.i("sql",""+cur.getCount());
            if (cur.moveToFirst()){
                Log.i("sql","ip="+cur.getString(1));
                Log.i("sql","port="+cur.getString(2));
            srv_ip.setText(cur.getString(1));
            srv_passord.setText(cur.getString(2));
        }}

    }

    public void open_wifi_settings(View view) {
        startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
    }

    public void connect_to_server(View view) {
        Cursor cur= sqliteHelper.get_Server();

          if (cur.getCount()==0){
              Log.i("sql","count ="+cur.getCount());
              sqliteHelper.addServer(srv_ip.getText().toString().trim(),srv_passord.getText().toString().trim() );
        }else {
              Log.i("sql","count ="+cur.getCount());
              sqliteHelper.delete_Server();
              sqliteHelper.addServer(srv_ip.getText().toString().trim(),srv_passord.getText().toString().trim() );
          }

       PinG pinG=new PinG(LoginServer.this);
        pinG.execute();
        ConnectRequestObj connectRequestObj=new ConnectRequestObj(LoginServer.this);
        connectRequestObj.execute(new Request(Utils.getIPAddress(true),
                "oussama" ,srv_ip.getText().toString().trim(),1999,
               Integer.parseInt( srv_passord.getText().toString().trim() ),"hi"),
                srv_ip.getText().toString().trim(),
                Integer.parseInt(srv_passord.getText().toString().trim())); /**/

    }

    public static class ConnectRequestObj extends AsyncTask<Object, String, Void> {
        private WeakReference<LoginServer> activityWeakReference;
        ConnectRequestObj(LoginServer activity) {
            activityWeakReference = new WeakReference< LoginServer>(activity);
        }

        @SuppressLint("WrongThread")
        @Override
        protected Void doInBackground(Object... objects) {

            Request request=(Request)objects[0];
         //   String ip=""+objects[1];
            int port=(Integer) objects[2];

            DatagramPacket packet;
            DatagramSocket socket=null;
            try { Log.i("udp","port"+port);
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                Log.i("udp","xxxxxxx");
                ObjectOutputStream oos = new ObjectOutputStream(baos);
                Log.i("udp","rr");
                oos.writeObject(request);
                Log.i("udp","ddddddd");
                oos.flush();
                Log.i("udp","2222");
                // get the byte array of the object
                byte[] Buf= baos.toByteArray();

                int number = Buf.length;;
                byte[] data = new byte[4];
                Log.i("udp","3333");
                // int -> byte[]
                for (int i = 0; i < 4; ++i) {
                    int shift = i << 3; // i * 8
                    data[3-i] = (byte)((number & (0xff << shift)) >>> shift);
                    Log.i("udp n","i "+i+"  shift "+shift+" data.lenth "+data.length+" nom "+number);
                }
                Log.i("udp","4444");
                  socket = new DatagramSocket();//1233
                InetAddress client = InetAddress.getByName(request.getServer_ip());
                  packet = new DatagramPacket(data, 4, client, port);
                socket.send(packet);
                Log.i("udp","5555");
                // now send the payload
                packet = new DatagramPacket(Buf, Buf.length, client, port);
                socket.send(packet);

                Log.i("udp","DONE SENDING");

                socket.close();
                socket = new DatagramSocket(7000);



                byte msg1[] = new byte[2];
                packet = new DatagramPacket(msg1, msg1.length);
                Log.i("udp","receive 2nd");
                socket.receive(packet);
                String strig = new String(msg1, StandardCharsets.UTF_8);
                Log.i("udp","---------"+strig);
               onProgressUpdate(strig);
/*
                byte[] answer = new byte[4];
                Log.i("udp"," ,,,,,,,,,,," );
                packet = new DatagramPacket(answer, answer.length);
                Log.i("udp"," getMtttttttttttttttttttttsg" );
                socket.receive(packet);
                Log.i("udp"," nnngkjksksgfiidk"+request.getMsg());
               String msg_received = new String(answer, 0, packet.getLength());
                Log.i("udp"," msg_received= "+msg_received );
                */

            } catch(Exception e) {
                e.printStackTrace();
            }finally
            {
                if (socket != null)
                {
                    socket.close();
                }
            }
            /*
            String msg_received;
            while(true) {
                byte[] lMsg = new byte[4096];
                DatagramPacket dp = new DatagramPacket(lMsg, lMsg.length);
                DatagramSocket ds = null;
                try{
                    if (ds == null) {
                        ds = new DatagramSocket(null);
                        ds.setReuseAddress(true);
                        ds.setBroadcast(true);
                        ds.bind(new InetSocketAddress(1239));
                    }

                    Log.i("udp a : ","1111111111111111111111111111111111 ");
                    ds.receive(dp);
                    Log.i("udp a : ","22222222222222222222222222222222 ");
                    msg_received = new String(lMsg, 0, dp.getLength());
                    Log.i("udp b : ","33: "+msg_received);
                    onProgressUpdate(msg_received);
                    Log.i("udp a : ","444444444444444444444 ");

                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
                finally
                {
                    if (ds != null)
                    {
                        ds.close();
                    }
                }}
*/

            return null;
        }



        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            String msg=""+values[0];
            Log.i("udp","---------"+msg);
            LoginServer activity = activityWeakReference.get();
            if (activity == null || activity.isFinishing()) {
                return;
            }
            if (msg.equals("ok")){      Log.i("udp","yes");
                Intent i=new Intent(activity, Pair.class);
                activity.startActivity(i);
            activity.    finish();
            }
            Toast.makeText(activity.getApplicationContext(),msg, Toast.LENGTH_SHORT).show();
        }
    }


    public static class ConnectRequest extends AsyncTask<Object, Void, Void> {
        private WeakReference<LoginServer> activityWeakReference;
        ConnectRequest(LoginServer activity) {
            activityWeakReference = new WeakReference< LoginServer>(activity);
        }

        @Override
        protected Void doInBackground(Object... objects) {
            Request request = (Request) objects[0];
            Log.i("udp msgto : ",request.getServer_ip());
            DatagramSocket ds = null;
            try
            {
                ds = new DatagramSocket();
                DatagramPacket dp;
                dp = new DatagramPacket(request.getMsg().getBytes(), request.getMsg().length());
                dp.setAddress( InetAddress.getByName(request.getServer_ip()));
                dp.setPort(request.getPort());

                ds.setBroadcast(true);
                Log.i("udp a : ",""+request.getPort());
                ds.send(dp);
                Log.i("udp b : ",""+request.getPort());
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            finally
            {
                if (ds != null)
                {
                    ds.close();
                }
            }
            return null;
        }
    }






    public static class PinG extends AsyncTask<Object, String, Void> {
        String str = "";
        private WeakReference<LoginServer> activityWeakReference;

        PinG(LoginServer activity)  {
            activityWeakReference = new WeakReference<LoginServer>(activity);
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            LoginServer activity = activityWeakReference.get();
            if (activity == null || activity.isFinishing()) {
                return;
            }
            str=activity.srv_ip.getText().toString().trim();
        }

        @SuppressLint("WrongThread")
        @Override
        protected Void doInBackground(Object... objects) {
            //  str=""+objects[0];
            try {
                InetAddress inet = null;
                inet = InetAddress.getByName(str);
                if (inet.isReachable(300)) {
                    onProgressUpdate("exist");

                } else onProgressUpdate("doesn't exist");
            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            String msg=""+values[0];

            LoginServer activity = activityWeakReference.get();
            if (activity == null || activity.isFinishing()) {
                return;
            }
            Log.i("udp", "onProgressUpdate: "+msg);
            // Toast.makeText(activity.getApplicationContext(),""+values[0], Toast.LENGTH_SHORT).show();

        }
    }

}