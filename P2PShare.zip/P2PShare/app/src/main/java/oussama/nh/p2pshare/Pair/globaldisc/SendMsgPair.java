package oussama.nh.p2pshare.Pair.globaldisc;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

import oussama.nh.p2pshare.Pair.Pair;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.MSG;

public class SendMsgPair implements Runnable{
    MSG msg;
    SqliteHelper sqliteHelper;
    int port;
    Pair pair;

    public SendMsgPair(MSG msg, SqliteHelper sqliteHelper, int port) {//, Pair pair
        this.msg = msg;
        this.sqliteHelper = sqliteHelper;
        this.port = port;
        this.pair = pair;
    }

    @Override
    public void run() {
        Log.i("shared","^:^");

        Log.i("shared","^:^^");
        try {
            DatagramSocket socket = new DatagramSocket();
            ByteArrayOutputStream bStream = new ByteArrayOutputStream();
            ObjectOutput oo = new ObjectOutputStream(bStream); Log.i("shared","^:^^^");
            oo.writeObject(msg);
            oo.close();
            Log.i("shared","^:^^^^^^^");
            Log.i("shared","port"+port);
            byte[] serializedMessage = bStream.toByteArray();
            DatagramPacket send_= new DatagramPacket(serializedMessage, serializedMessage.length, InetAddress.getByName("224.0.0.10"), port);
            sqliteHelper.addGlobalDisc("me",msg.getTxt());
//            pair.runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    pair.updatetablayout_globaldis();
//
//                                    }
//            });
            Log.i("shared","^:ù");
            socket.send(send_);
            socket.close();
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
