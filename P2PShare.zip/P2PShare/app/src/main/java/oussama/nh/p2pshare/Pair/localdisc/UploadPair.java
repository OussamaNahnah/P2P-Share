package oussama.nh.p2pshare.Pair.localdisc;

import android.util.Log;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import oussama.nh.p2pshare.Pair.Pair;
import oussama.nh.p2pshare.Server.Server;
import oussama.nh.p2pshare.shared.File_;

public class UploadPair implements Runnable {
    Pair pair;
    int port;



    public UploadPair(Pair pair, int port) {
        this.pair = pair;
        this.port = port;
    }

    @Override
    public void run() {
        File file = null;
        File_ file_ = null;

        Log.i("up1srv", "s1");
        DatagramSocket socket = null;
        Socket client=null;
        while (true) {
            try {
                socket = new DatagramSocket(port);

                byte[] buf = new byte[256];
                Log.i("up1srv", "s11");
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                Log.i("up1srv", "s111");
                socket.receive(packet);
                Log.i("up1srv", "s2");
                socket.close();
                ObjectInputStream iStream = new ObjectInputStream(new ByteArrayInputStream(buf));
                  file_ = (File_) iStream.readObject();
                Log.i("up1srv", "name" + file_.getName());
                Log.i("up1srv", "owner" + file_.getOwner());
                Log.i("up1srv", "type" + file_.getType());
                Log.i("up1srv", "size" + file_.getSize());
                try {


                 file =new File(file_.getName());
                if(file == null || !file.exists()) {
                    Log.i("up1srv", "not exict");
                }else
                Log.i("up1srv", "exict");
                }catch (Exception e){
                    Log.i("up1srv","eer"+e.getMessage());
                }finally {
                    if (socket!=null)socket.close();
                }

           ////////////////////////////////////////////////////////////////////////////

                Log.i("up1srv", "a"+port+1);
                  client = new Socket(InetAddress.getByName(file_.getRequster()), 9186);
                Log.i("up1srv", "bb:"+file_.getRequster());
                OutputStream outputStream = client.getOutputStream();
                Log.i("up1srv", "cc");
                byte[] buffer = new byte[1024];

                Log.i("up1srv", "dd "+file.getName());
                FileInputStream in = new FileInputStream(file);
                Log.i("up1srv", "ee");
                int rBytes;
                while((rBytes = in.read(buffer, 0, 1024)) != -1)
                {
                    outputStream.write(buffer, 0, rBytes);
                }
                Log.i("up1srv", "done");
                outputStream.flush();
                outputStream.close();
                client.close();


            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }finally {
                if (client!=null){
                    try {
                        client.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }
            }

        }
    }




}