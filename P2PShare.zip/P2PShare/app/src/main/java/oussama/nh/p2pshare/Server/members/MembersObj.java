package oussama.nh.p2pshare.Server.members;

import java.io.Serializable;

public class MembersObj implements Serializable {
    String ip="";
    String name="";
    String active="";
    String last="";

    public MembersObj(String ip, String name, String active, String last) {
        this.ip = ip;
        this.name = name;
        this.active = active;
        this.last = last;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getLast() {
        return last;
    }

    public void setLast(String last) {
        this.last = last;
    }
}
