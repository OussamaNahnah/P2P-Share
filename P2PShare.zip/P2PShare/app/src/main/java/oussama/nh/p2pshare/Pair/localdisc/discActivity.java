package oussama.nh.p2pshare.Pair.localdisc;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import oussama.nh.p2pshare.Pair.globaldisc.MessgesAdapter;
import oussama.nh.p2pshare.Pair.globaldisc.SendMsgPair;
import oussama.nh.p2pshare.R;
import oussama.nh.p2pshare.Server.localdisc.SendLocalMsgSrv;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.MSG;
import oussama.nh.p2pshare.shared.Utils;

public class discActivity extends AppCompatActivity {
    TextView dusc_with;
    EditText txt;
    Button send;
    SqliteHelper sqliteHelper;
    MessgesLocalAdapter message_adapter;
    ArrayList<MSG> msgs;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disc);
        Intent intent=getIntent();
        String loadip = getIntent().getStringExtra("ip_partner");
        sqliteHelper = new SqliteHelper(getApplicationContext());
        txt =findViewById(R.id.PairTxtMsg_);
        send = findViewById(R.id.PairSendMsg_);
        dusc_with = findViewById(R.id.dusc_with);
        dusc_with.setText(loadip);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("sendlovlmsgsrv","add to db");
                sqliteHelper.addLocalDisc(Utils.getIPAddress(true),loadip,
                        txt.getText().toString());
                Log.i("sendlovlmsgsrv","added");
                Thread send = new Thread(new SendLocalMsgPAir(loadip,sqliteHelper,new MSG(Utils.getIPAddress(true),
                        txt.getText().toString()),
                        9198));
                send.start();
            }
        });

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        linearLayoutManager.setStackFromEnd(true);

        recyclerView = (RecyclerView)findViewById(R.id.pair_local_disc);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(linearLayoutManager);

        msgs=new ArrayList<>();
        Cursor res=sqliteHelper.getlocaldisc();
        if (res.getCount() == 0) {
            Toast.makeText(recyclerView.getContext(), "count =0", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(recyclerView.getContext(), "kayan", Toast.LENGTH_LONG).show();
            while (res.moveToNext()) {
                msgs.add(new MSG(res.getString(0),res.getString(1),res.getString(2)));

            }
        }

       /*   msgs.add(new MSG("thtgt","rthr"));
        msgs.add(new MSG("fefe","rtfefhr"));
        msgs.add(new MSG("me","rtefsfhr"));
        msgs.add(new MSG("grdgrd","rtesfehr"));
        msgs.add(new MSG("me","fsf"));
*/

        message_adapter = new MessgesLocalAdapter(msgs);
        recyclerView.setAdapter(message_adapter);
    }
}