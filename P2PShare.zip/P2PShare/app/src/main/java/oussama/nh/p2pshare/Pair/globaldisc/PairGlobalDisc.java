package oussama.nh.p2pshare.Pair.globaldisc;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

import oussama.nh.p2pshare.R;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.MSG;
import oussama.nh.p2pshare.shared.Utils;


public class PairGlobalDisc extends Fragment {
    EditText txt;
    Button send;
    SqliteHelper sqliteHelper;
    MessgesAdapter message_adapter;
    ArrayList<MSG> msgs;
    RecyclerView recyclerView;

    public PairGlobalDisc() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_pair_global_disc, container, false);
        sqliteHelper = new SqliteHelper(getContext());
        Log.i("nahnah", "PairGlobalDisc ");
        txt = root.findViewById(R.id.PairTxtMsg);
        send = root.findViewById(R.id.PairSendMsg);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Thread send = new Thread(new SendMsgPair(new MSG(Utils.getIPAddress(true),
                        txt.getText().toString()),
                        sqliteHelper,
                        9994));
                send.start();
            }
        });


        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setStackFromEnd(true);

        recyclerView = (RecyclerView)root.findViewById(R.id.pair_glabal_disc);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(linearLayoutManager);

        msgs=new ArrayList<>();
     Cursor res=sqliteHelper.getGlobalDisc();
        if (res.getCount() == 0) {
            Toast.makeText(recyclerView.getContext(), "count =0", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(recyclerView.getContext(), "kayan", Toast.LENGTH_LONG).show();
            while (res.moveToNext()) {
                msgs.add(new MSG(res.getString(0),res.getString(1)));

            }
        }
/*
          msgs.add(new MSG("thtgt","rthr"));
        msgs.add(new MSG("fefe","rtfefhr"));
        msgs.add(new MSG("me","rtefsfhr"));
        msgs.add(new MSG("grdgrd","rtesfehr"));
        msgs.add(new MSG("me","fsf"));
*/

    message_adapter = new MessgesAdapter(msgs);
    recyclerView.setAdapter(message_adapter);
        return root;
    }
}