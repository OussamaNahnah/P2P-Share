package oussama.nh.p2pshare;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

import oussama.nh.p2pshare.Pair.LoginServer;
import oussama.nh.p2pshare.Pair.Pair;
import oussama.nh.p2pshare.Server.Server;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.Utils;

public class MainActivity extends AppCompatActivity {
TextView tv;
SqliteHelper sqliteHelper;
    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        verifyStoragePermissions(this);
        sqliteHelper=new SqliteHelper(getApplicationContext());
        sqliteHelper.delete_all();
        tv=findViewById(R.id.tv);
        tv.setText(Utils.getIPAddress(true));
        Toast.makeText(getApplicationContext(), Utils.getIPAddress(true),Toast.LENGTH_SHORT).show();


        File file = new File(Environment.getExternalStorageDirectory()+"/aaP2PShare");

        if (!file.mkdirs()) {
            file.mkdirs();
        }
        boolean success = true;
        if(!file.exists()) {
            Toast.makeText(getApplicationContext(),"Directory does not exist, create it",
                    Toast.LENGTH_LONG).show();
        }
        if(success) {
            Toast.makeText(getApplication(),"Directory created",
                    Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(this,"Failed to create Directory",
                    Toast.LENGTH_LONG).show();
        }


    }    public void createServer(View view) {
        Intent i=new Intent(this, Server.class);
        startActivity(i);
    }

    public void joinServer(View view) {
        Intent i=new Intent(this, LoginServer.class);
        startActivity(i);
    }
    public static void verifyStoragePermissions(Activity activity) {
        // Check if we have write permission
        int permission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        Log.i("razt"," i have permission so prompt the user");
        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            Log.i("razt"," // We don't have permission so prompt the user");
            ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
        }
    }


}