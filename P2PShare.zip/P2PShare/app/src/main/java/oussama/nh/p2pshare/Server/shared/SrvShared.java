package oussama.nh.p2pshare.Server.shared;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.lang.ref.WeakReference;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

import oussama.nh.p2pshare.Pair.Pair;
import oussama.nh.p2pshare.Pair.shared.PairShared;
import oussama.nh.p2pshare.Pair.shared.RequestDownload;
import oussama.nh.p2pshare.Pair.shared.SendFile;
import oussama.nh.p2pshare.R;
import oussama.nh.p2pshare.Server.Server;
import oussama.nh.p2pshare.Server.members.MembersAdapter;
import oussama.nh.p2pshare.Server.members.MembersObj;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.File_;
import oussama.nh.p2pshare.shared.PathUtil;
import oussama.nh.p2pshare.shared.Utils;


public class SrvShared extends Fragment {
    static SrvSharedAdapter srvSharedAdapter;
    static SqliteHelper sqliteHelper;
    static ArrayList<File_> file_s;
    static RecyclerView recyclerView;

    public static final int PICKFILE_RESULT_CODE = 1;
    private Uri fileUri;
    private String filePath;
    public SrvShared() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_srv_shared, container, false);
        sqliteHelper=new SqliteHelper(root.getContext());
       // Server.test();



        Button share_file=root.findViewById(R.id.srv_share_file);
        share_file.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent chooseFile = new Intent(Intent.ACTION_GET_CONTENT);
                chooseFile.setType("*/*");
                chooseFile = Intent.createChooser(chooseFile, "Choose a file");
                startActivityForResult(chooseFile, PICKFILE_RESULT_CODE);


            }
        });


        file_s  = new ArrayList<>();
        // set up the RecyclerView
        recyclerView =root. findViewById(R.id.srv_sharedfiles_recycle);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        srvSharedAdapter = new SrvSharedAdapter(getContext(), file_s);
        srvSharedAdapter.setClickListener(new SrvSharedAdapter.ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Log.i("ResqtDow", "s111");
                Thread send=new Thread(new RequestDownloadSRV((Server) getActivity(),9119,srvSharedAdapter.getItem(position)));
                send.start();
                Toast.makeText(getContext(), "You clicked " + srvSharedAdapter.getItem(position) + " on row number " + position, Toast.LENGTH_SHORT).show();
            }
        });

        try{


            //  Cursor res=null;
            Cursor res=sqliteHelper.get_Files();
            if (res.getCount() == 0) {
                Toast.makeText(recyclerView.getContext(), "count =0", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(recyclerView.getContext(), "kayan", Toast.LENGTH_LONG).show();
                while (res.moveToNext()) {
                    file_s.add(new File_(res.getString(1),res.getString(2),res.getString(3),res.getString(4),res.getString(5)));

                }
            }}catch (Exception e){
            Log.i("errer",e.getMessage());
        }
        recyclerView.setAdapter(srvSharedAdapter);
        return root;
    }

    @Override

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case PICKFILE_RESULT_CODE:
                if (resultCode == -1) {
                    fileUri = data.getData();
                    filePath = fileUri.getPath();
                    Log.i("shared","url:"+filePath);
                    Toast.makeText(getContext(),"url:"+filePath,Toast.LENGTH_SHORT).show();
                    //  tvItemPath.setText(filePath);

                    //***********************
                    long size=0;

                    ContentResolver cR = getContext().getContentResolver();
                    MimeTypeMap mime = MimeTypeMap.getSingleton();
                    String type = mime.getExtensionFromMimeType(cR.getType(fileUri));
                    Log.i("shared","type:"+type);
                    try {
                        size= cR.openFileDescriptor(fileUri,"r").getStatSize();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    Log.i("shared","size:"+size);
                    String path = fileUri.getPath();
//                    String path = fileUri.toString();
                    Log.i("shared","path:"+path);

                    ///////////////////////////
                    String filePathh=null;
                    try {
                         filePathh= PathUtil.getPath(getContext(),fileUri);
                        Log.i("shared", "fffffffffffffffffff;"+filePathh);
                    } catch (URISyntaxException e) {
                        e.printStackTrace();
                    }
                    File file = null;
                    try {


                         file = new File(filePathh);
                        if(file.exists()) {
                            Log.i("shared", "exict");
                        }else    Log.i("shared", "not exict");

                    }catch (Exception e){
                        Log.i("shared","eer"+e.getMessage());
                    }

                    sqliteHelper.addFile(Utils.getIPAddress(true),file.getName(),path,type,""+size);
                    File_ ff=new File_(Utils.getIPAddress(true),file.getName(),fileUri.getPath(),type,""+size);

                   Thread sendfile=new Thread(new SendfileSrv(ff ,sqliteHelper));
               //     Thread sendfile=new Thread(new SendfileSrv( new File_(Utils.getIPAddress(true),filePathh,type,""+size),sqliteHelper));
                    sendfile.start();

                    //
                    Log.i("shared","sended");
                }
                break;
        }
    }


}