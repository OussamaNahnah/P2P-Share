package oussama.nh.p2pshare.Server.members;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;

import oussama.nh.p2pshare.R;
import oussama.nh.p2pshare.database.SqliteHelper;

public class SrvMembers extends Fragment {
    static MembersAdapter membersAdapter;
static SqliteHelper sqliteHelper;
static ArrayList<MembersObj> membersObjs;
    static RecyclerView recyclerView;
    public SrvMembers() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root= inflater.inflate(R.layout.fragment_srv_members, container, false);

Log.i("nahnah","members");
        // data to populate the RecyclerView with
      /*
        membersObjs.add(new MembersObj("127.0.0.1"));
        membersObjs.add(new MembersObj("192.168.0.1"));
        membersObjs.add(new MembersObj("192.168.0.5"));
        membersObjs.add(new MembersObj("192.168.0.10"));
        membersObjs.add(new MembersObj("192.168.0.15"));
        membersObjs.add(new MembersObj("192.168.0.19"));
        membersObjs.add(new MembersObj("192.168.0.2"));
        membersObjs.add(new MembersObj("192.168.0.3"));
        membersObjs.add(new MembersObj("192.168.0.14"));
        membersObjs.add(new MembersObj("192.168.0.32"));
        membersObjs.add(new MembersObj("192.168.0.34"));
        membersObjs.add(new MembersObj("192.168.0.31"));

*/
        sqliteHelper=new SqliteHelper(root.getContext());
        membersObjs  = new ArrayList<>();
        // set up the RecyclerView
        recyclerView =root. findViewById(R.id.srv_members_recylrview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        membersAdapter = new MembersAdapter(getContext(), membersObjs);
        membersAdapter.setClickListener(new MembersAdapter.ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Toast.makeText(getContext(), "You clicked " + membersAdapter.getItem(position) + " on row number " + position, Toast.LENGTH_SHORT).show();
            }
        });

        update();
        return root;
    }
   public static void update(){
        try{


            //  Cursor res=null;
            Cursor res=sqliteHelper.get_Members();
            if (res.getCount() == 0) {
                Toast.makeText(recyclerView.getContext(), "count =0", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(recyclerView.getContext(), "kayan", Toast.LENGTH_LONG).show();
                while (res.moveToNext()) {
                    membersObjs.add(new MembersObj(res.getString(1),res.getString(2),res.getString(3), res.getString(4)));

                }
            }}catch (Exception e){
            Log.i("errer",e.getMessage());
        }
        recyclerView.setAdapter(membersAdapter);

    }

}