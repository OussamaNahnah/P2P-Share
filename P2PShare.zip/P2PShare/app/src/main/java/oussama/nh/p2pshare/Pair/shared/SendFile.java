package oussama.nh.p2pshare.Pair.shared;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

import oussama.nh.p2pshare.shared.File_;

public class SendFile implements Runnable {
    File_ file_;
    String ip_server;

    public SendFile(File_ file_, String ip_server) {
        this.file_ = file_;
        this.ip_server = ip_server;
    }

    @Override
    public void run() {
            Log.i("shared","^:^");
       
            Log.i("shared","^:^^");
            try {
                DatagramSocket socket = new DatagramSocket();
                ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                ObjectOutput oo = new ObjectOutputStream(bStream); Log.i("shared","^:^^^");
                oo.writeObject(file_);
                oo.close();
                Log.i("shared","^:^^^^^^^");
                byte[] serializedMessage = bStream.toByteArray();
                DatagramPacket send_= new DatagramPacket(serializedMessage, serializedMessage.length, InetAddress.getByName(ip_server), 9998);
                Log.i("shared","^:ù");
                socket.send(send_);
                socket.close();
            } catch (SocketException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
    }
}