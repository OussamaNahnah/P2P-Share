package oussama.nh.p2pshare.Pair.shared;

import android.util.Log;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.ArrayList;

import oussama.nh.p2pshare.Pair.Pair;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.File_;

public class RecieveFilesDBOFFLINE implements Runnable {
    SqliteHelper sqliteHelper;
    Pair context;

    public RecieveFilesDBOFFLINE(SqliteHelper sqliteHelper, Pair context) {
        this.sqliteHelper = sqliteHelper;
        this.context = context;
    }

    @Override
    public void run() {
        try {
            Log.i("rfiles2","creceive shared ");
            //******************principal**********************
            MulticastSocket socket = null;
            socket = new MulticastSocket(9986);
            Log.i("rfiles2",",, ");
            InetAddress group = InetAddress.getByName("224.0.0.5");
            Log.i("rfiles2",",,, ");
            socket.joinGroup(group);
            DatagramPacket packet;
            Log.i("rfiles2",",,p ");
            byte[] buf = new byte[5000];
            ObjectInputStream iStream;
            Log.i("rfiles2",",,kp ");
            packet = new DatagramPacket(buf, buf.length);
            Log.i("rfiles2",",,àp ");
            while(true)
            { Log.i("rfiles2",",,pp ");
                socket.receive(packet);
                Log.i("rfiles2",",,ppp ");
                iStream = new ObjectInputStream(new ByteArrayInputStream(buf));
                ArrayList<File_> res = (ArrayList<File_>) iStream.readObject();
                Log.i("rfiles2","count: " + res.size());
                sqliteHelper.delete_Files();
                for (int i=0;i<res.size();i++){

                    Log.i("rfiles2","count: " + res.get(i).getName());
                    sqliteHelper.addFile( res.get(i).getOwner(), res.get(i).getName(), res.get(i).getPath(), res.get(i).getType(),res.get(i).getSize());
                }
                context.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        context.updatetablayout();

                    }
                });

                iStream.close();
                socket.leaveGroup(group);
                socket.close();
            }

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }


    }
}
