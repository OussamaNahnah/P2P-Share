package oussama.nh.p2pshare.Server.globaldisc;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

import oussama.nh.p2pshare.Server.Server;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.MSG;

public class SendMsgSrv implements Runnable{
    MSG msg;
    SqliteHelper sqliteHelper;
    int port;
    SrvGlobalDisc server;

    public SendMsgSrv(MSG msg, SqliteHelper sqliteHelper, int port, SrvGlobalDisc server) {
        this.msg = msg;
        this.sqliteHelper = sqliteHelper;
        this.port = port;
        this.server = server;
    }

    @Override
    public void run() {


        Log.i("sendmsgsrv","^:^^");
        try {
            DatagramSocket socket = new DatagramSocket();
            ByteArrayOutputStream bStream = new ByteArrayOutputStream();
            ObjectOutput oo = new ObjectOutputStream(bStream); Log.i("sendmsgsrv","^:^^^");
            oo.writeObject(msg);
            oo.close();
            Log.i("sendmsgsrv","^:^^^^^^^");
            Log.i("sendmsgsrv","port"+port);
            byte[] serializedMessage = bStream.toByteArray();
            DatagramPacket send_= new DatagramPacket(serializedMessage, serializedMessage.length, InetAddress.getByName("224.0.0.3"), port);
            sqliteHelper.addGlobalDisc("me",msg.getTxt());
            Log.i("sendmsgsrv","msg"+msg.getTxt());
         /*   server.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    server.updatetablayout_globaldis();
                }
            });*/
            Log.i("sendmsgsrv","sended");
            socket.send(send_);
            socket.close();
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
